ALTER TABLE IF EXISTS dbo.user_review
    ADD COLUMN user_review_title text COLLATE pg_catalog."default";