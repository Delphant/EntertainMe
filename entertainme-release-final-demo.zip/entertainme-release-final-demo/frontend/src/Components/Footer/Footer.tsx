import styles from "../Footer/Footer.module.css";

const Footer = () => {
  return <div className={styles.footer}>Copyright © EntertainMe! 2023</div>;
};

export default Footer;
