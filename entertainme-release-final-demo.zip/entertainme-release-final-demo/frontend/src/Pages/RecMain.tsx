import Recommend from "../Components/Recommendation/Recommend";

function RecMain() {
  return (
    <div>
      <Recommend />
    </div>
  );
}

export default RecMain;
