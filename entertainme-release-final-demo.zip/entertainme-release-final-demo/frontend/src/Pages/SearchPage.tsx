import React from "react";
import Search from "../Components/Search/Search";

function SearchPage() {
  return <Search />;
}

export default SearchPage;
