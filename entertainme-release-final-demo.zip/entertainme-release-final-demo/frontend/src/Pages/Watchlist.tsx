import WatchlistComp from "../Components/Watchlist/WatchlistComp";

function Watchlist() {
  return <WatchlistComp />;
}

export default Watchlist;
