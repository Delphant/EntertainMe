import Title from "../Components/Title/Title";

function titlePage() {
  return (
    <>
      <Title />
    </>
  );
}

export default titlePage;
